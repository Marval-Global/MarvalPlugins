
  

# Entra Creation Plugin for MSM

This plugin facilitates the creation of entra ID users with Marval.
You can setup a request action, with approvals, and call this plugin to initiate user creation and onboarding.
  
## Compatible Versions


| Plugin | MSM |
|---------|-------------|
| All versions | All versions |


## Installation

See the Plug-in tab for information on how to install the plugin.

### Contributing

We welcome all feedback including feature requests and bug reports. Please raise these as issues on GitHub. If you would like to contribute to the project please fork the repository and issue a pull request.
