    let pluginName = "MarvalSoftware.Plugins.EntraCreation";

    const options = window.validationOptions || {};
    console.log("Validation options:", options);
       $ = window.validationOptions.jq;
       var Integration = window.validationOptions.Integration;
      
       var csspath = "https://" + window.top.location.host + Integration._getPluginPath() + "landingPageStyles.css";
       var document = window.validationOptions.document;
       var _fullPluginPathHandler = "https://" + window.top.location.host + Integration._getPluginPath() + "Handler/Handler.ashx";
       // var _fullPluginPathHandler = "https://" + window.top.location.host + this._getPluginPath() + "Handler/Handler.ashx";
       // console.log("Have handler in injected code as ", _fullPluginPathHandler)
       // var csspath = "https://" + currentUrl + EntraCreation._getPluginPath() + "landingPageStyles.css";
       var HeaderText = $('#ctl00_ctl00_cph_entityHeaderText').text();
       console.log("Header text is ", HeaderText);
       var currentUrl = window.top.location.href;
       console.log("In plugin code1 from ", pluginName)
       if (currentUrl.includes("Plugin.aspx") && HeaderText == pluginName) {
                $(document).ready(function () {
              $('#ctl00_ctl00_cph_maintenance_pluginDetailsFieldSet, #ctl00_ctl00_cph_maintenance_manifestDetailsFieldSet')
                .wrapAll('<div class="details-container"></div>');

              $('.details-container').css({
                'display': 'flex',
                'gap': '20px',
                'flex-flow': 'horizontal',
                'flex-wrap': 'wrap'
              });

              $('#ctl00_ctl00_cph_maintenance_pluginDetailsFieldSet, #ctl00_ctl00_cph_maintenance_manifestDetailsFieldSet').css({
                'flex': '1',
                'min-width': '300px',
                'border': '2px solid #4A90E2',
                'border-radius': '8px',
                'padding': '20px',
                'margin': '0',
                'background': 'linear-gradient(135deg, #f8fbff 0%, #e8f4fd 100%)',
                'box-shadow': '0 4px 12px rgba(74, 144, 226, 0.15)'
              });

              $('#ctl00_ctl00_cph_maintenance_pluginDetailsFieldSet legend, #ctl00_ctl00_cph_maintenance_manifestDetailsFieldSet legend').css({
                'font-weight': 'bold',
                'padding': '8px 16px',
                'background': '#4A90E2',
                'color': 'white',
                'border-radius': '6px',
                'border': 'none',
                'font-size': '14px',
                'box-shadow': '0 2px 4px rgba(74, 144, 226, 0.3)'
              });
            });
            
            var pluginKeyValue = Integration._getPluginKey();
            $('#ct100_overlay_id1').hide();
            $('#ctl00_ctl00_cph_maintenance_overviewTabPage').wrap('<div id="pluginWrapper"></div>');
            $('#ctl00_ctl00_cph_maintenance_overviewTabPage').hide();
            var pluginWrapper = `
           <link rel="stylesheet" type="text/css" href="${csspath}">
           <canvas id="canvas"></canvas>
           <div class="overlay">
              <div class="container">
                <h1 class="bluetext">Marval Integration Platform</h1>
                <p class="subtitle">Activate Your Integration</p>
              <div class="input-group integration">
                <!--<label for="licenseKey">License Key</label> -->
                <input type="text" id="licenseKey" placeholder="Enter your license key for activation..." />
            </div>
            <button class="activate-btn" id="activateIntegration">
                Activate Integration
            </button>
               <br><br>
                 <button class="activate-btn" id="learnMore">
                Learn More
            </button>
           <!-- <div class="responsecontainer" > -->
          <div id="statusMessageError" class="status-message error"></div>
          <div id="statusMessageGood" class="status-message success"></div>
          <!-- </div> -->
        </div>
    </div>
            `;
             if (!pluginKeyValue) {
              console.log("In status message error")
              $('#pluginWrapper').append(pluginWrapper);

              const LPscript = document.createElement('script');
              LPscript.src = 'landingPageCode.js';
              LPscript.onload = function () { console.log('landingPageCode.js loaded'); };
              document.head.appendChild(LPscript);
              // window.top.document.getElementById("learnMore").onclick = learnMore;
               window.top.document.getElementById("activateIntegration").onclick = activateIntegration;
            } else {
              var getTokenResponse = fetch(_fullPluginPathHandler, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  action: "validatePluginKey",
                  pluginKey: pluginKeyValue
                })
              }).then(response => {
                if (!response.ok) {
                  console.log("Had error eresponse")
                  throw new Error(`HTTP error! status: ${response.status}`);
                  //  $('#ctl00_ctl00_cph_maintenance_overviewTabPage').append(`
                  $('#pluginWrapper').append(pluginWrapper);
                  const LPscript = document.createElement('script');
                  LPscript.src = 'landingPageCode.js';
                  LPscript.onload = function () { console.log('landingPageCode.js loaded'); };
                  document.head.appendChild(LPscript);
                  //window.top.document.getElementById("learnMore").onclick = learnMore;
                  window.top.document.getElementById("activateIntegration").onclick = activateIntegration;
                }
                return response.json();
              })
                .then(data => {
                  console.log('Success:', data);
                  if (!data.error) {
                    $('#ctl00_ctl00_cph_maintenance_overviewTabPage').fadeIn();
                  } else {
                    $('#pluginWrapper').append(pluginWrapper);
                    const LPscript = document.createElement('script');
                    LPscript.src = 'landingPageCode.js';
                    LPscript.onload = function () { console.log('landingPageCode.js loaded'); };
                    document.head.appendChild(LPscript);
                    //window.top.document.getElementById("learnMore").onclick = learnMore;
                    window.top.document.getElementById("activateIntegration").onclick = activateIntegration;
                  }
                  return data;
                })
                .catch(error => {
                  console.error('Error:', error);
                });
         }

          async function activateIntegration() {
              event.preventDefault();
              console.log("Activating Integration");
              var integrationToken = $('#licenseKey').val();
              fetch(_fullPluginPathHandler, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  action: "validatePluginKey",
                  pluginKey: integrationToken
                })

              }).then(response => {
                response.json().then(data => {
                  console.log("Have activated integration with result", data);
                  // $('#statusMessageGood').append("Your plugin is now activated, please wait...");

                  if (data.error) {
                    // console.log("Failure activating plugin");
                    $('#statusMessageError').empty();
                    $('#statusMessageGood').hide();
                    $('#statusMessageError').append("There was an error validating your plugin, please contact support.");
                    $('#statusMessageError').addClass('show');
                  } else {

                    console.log("Success, setting plugin key to " + integrationToken);
                    $('#statusMessageGood').empty();
                    $('#statusMessageError').hide();
                    $('#statusMessageGood').append("Your plugin is now activated, please wait...");
                    $('#statusMessageGood').addClass('show');
                    setTimeout(() => {
                      $('#ctl00_ctl00_cph_maintenance_pluginTStrip').css('opacity', '0');
                      $('.content').css('opacity', '0');
                      $('#ctl00_ctl00_cph_maintenance_overviewTabPage').show();
                      $('.content').css('opacity', '0');
                      Integration._setPluginKey(integrationToken);
                    }, 2000);
                  }



                })

              }).catch(error => {
                console.log("Have error ", error)

              })
              var url = "https://integration-dev.marval.cloud/integration/testToken/";

              console.log("Integration token token is " + integrationToken);


            }

  function showMessage(message, type, id) {
            const statusMessage = window.top.document.getElementById(id);
            statusMessage.textContent = message;
            statusMessage.className = `status-message ${type} show`;
            
            if (type === 'info') {
                statusMessage.style.background = 'rgba(33, 150, 243, 0.2)';
                statusMessage.style.color = '#64b5f6';
                statusMessage.style.border = '1px solid rgba(33, 150, 243, 0.3)';
            }
        }

      // function activateIntegration(e) {
      //       console.log("Clicked activate integration.")
      //       e.preventDefault();
      //       const licenseKey = window.top.document.getElementById('licenseKey').value.trim();
      //       const statusMessage = window.top.document.getElementById('statusMessage');

      //       if (!licenseKey) {
      //           showMessage('Please enter a license key.', 'error', 'statusMessageError');
      //           return;
      //       }

      //       // Simulate API call
      //       showMessage('Activating integration...', 'info', 'statusMessageError');
            
      //       setTimeout(() => {
      //           // Simulate validation (in real implementation, this would be an API call)
      //           if (licenseKey.length >= 10) {
      //               showMessage('Integration activated successfully!', 'success', 'statusMessageGood');
      //               // Add some visual feedback
      //               window.top.document.querySelector('.activate-btn').style.background = 'linear-gradient(135deg, #4caf50 0%, #81c784 100%)';
      //               window.top.document.querySelector('.activate-btn').innerHTML = 'Activated ✓';
      //           } else {
      //               showMessage('Invalid license key. Please check and try again.', 'error', 'statusMessageError');
      //           }
      //       }, 2000);
      //   }

  
  }
