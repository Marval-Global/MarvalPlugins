function loadScript(url, callback)
{

    var head = document.head;
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;

  
    script.onreadystatechange = callback;
    script.onload = callback;

 // Fire the loading
    head.appendChild(script);
}
  
var codeToRun = function() {
  
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        //const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('canvas'), alpha: true });
        //renderer.setSize(window.innerWidth, window.innerHeight);
       // renderer.setClearColor(0x000000, 0);

      
        const particleCount = 200;
        const particles = new THREE.BufferGeometry();
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);
        const velocities = [];

        for (let i = 0; i < particleCount; i++) {
            positions[i * 3] = (Math.random() - 0.5) * 100;
            positions[i * 3 + 1] = (Math.random() - 0.5) * 100;
            positions[i * 3 + 2] = (Math.random() - 0.5) * 100;

            const color = new THREE.Color();
            color.setHSL(0.6 + Math.random() * 0.2, 0.8, 0.5 + Math.random() * 0.5);
            colors[i * 3] = color.r;
            colors[i * 3 + 1] = color.g;
            colors[i * 3 + 2] = color.b;

            velocities.push({
                x: (Math.random() - 0.5) * 0.02,
                y: (Math.random() - 0.5) * 0.02,
                z: (Math.random() - 0.5) * 0.02
            });
        }

        particles.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        particles.setAttribute('color', new THREE.BufferAttribute(colors, 3));

        const particleMaterial = new THREE.PointsMaterial({
            size: 0.5,
            vertexColors: true,
            transparent: true,
            opacity: 0.8,
            blending: THREE.AdditiveBlending
        });

        const particleSystem = new THREE.Points(particles, particleMaterial);
        scene.add(particleSystem);

        const lineGeometry = new THREE.BufferGeometry();
        const lineMaterial = new THREE.LineBasicMaterial({
            color: 0x64b5f6,
            transparent: true,
            opacity: 0.1
        });

        camera.position.z = 30;

        function animate() {
            requestAnimationFrame(animate);

            const positions = particleSystem.geometry.attributes.position.array;
            for (let i = 0; i < particleCount; i++) {
                positions[i * 3] += velocities[i].x;
                positions[i * 3 + 1] += velocities[i].y;
                positions[i * 3 + 2] += velocities[i].z;

                // Wrap around screen
                if (positions[i * 3] > 50) positions[i * 3] = -50;
                if (positions[i * 3] < -50) positions[i * 3] = 50;
                if (positions[i * 3 + 1] > 50) positions[i * 3 + 1] = -50;
                if (positions[i * 3 + 1] < -50) positions[i * 3 + 1] = 50;
                if (positions[i * 3 + 2] > 50) positions[i * 3 + 2] = -50;
                if (positions[i * 3 + 2] < -50) positions[i * 3 + 2] = 50;
            }

            particleSystem.geometry.attributes.position.needsUpdate = true;

            // Rotate the entire particle system slowly
            particleSystem.rotation.x += 0.001;
            particleSystem.rotation.y += 0.002;

          //  renderer.render(scene, camera);
        }

        animate();

        // Handle window resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            //renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // Integration activation functionality
        // function activateIntegration() {
        //     console.log("Clicked activate integration.")

        //     const licenseKey = document.getElementById('licenseKey').value.trim();
        //     const statusMessage = document.getElementById('statusMessage');

        //     if (!licenseKey) {
        //         showMessage('Please enter a license key.', 'error', 'statusMessageError');
        //         return;
        //     }

        //     // Simulate API call
        //     showMessage('Activating integration...', 'info', 'statusMessageGood');
            
        //     setTimeout(() => {
        //         // Simulate validation (in real implementation, this would be an API call)
        //         if (licenseKey.length >= 10) {
        //             showMessage('Integration activated successfully!', 'success', 'statusMessageGood');
        //             // Add some visual feedback
        //             document.querySelector('.activate-btn').style.background = 'linear-gradient(135deg, #4caf50 0%, #81c784 100%)';
        //             document.querySelector('.activate-btn').innerHTML = 'Activated ✓';
        //         } else {
        //             showMessage('Invalid license key. Please check and try again.', 'error', 'statusMessagError');
        //         }
        //     }, 2000);
        // }

        function showMessage(message, type) {
            const statusMessage = document.getElementById('statusMessage');
            statusMessage.textContent = message;
            statusMessage.className = `status-message ${type} show`;
            
            if (type === 'info') {
                statusMessage.style.background = 'rgba(33, 150, 243, 0.2)';
                statusMessage.style.color = '#64b5f6';
                statusMessage.style.border = '1px solid rgba(33, 150, 243, 0.3)';
            }
        }

        // Allow Enter key to activate
        // document.getElementById('licenseKey').addEventListener('keypress', (e) => {
        //     if (e.key === 'Enter') {
        //         activateIntegration();
        //     }
        // });

        // Add some interactive mouse effects
        document.addEventListener('mousemove', (e) => {
            const mouseX = (e.clientX / window.innerWidth) * 2 - 1;
            const mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
            
            camera.position.x = mouseX * 2;
            camera.position.y = mouseY * 2;
            camera.lookAt(0, 0, 0);
        });
//    function activateIntegration() {
//                 e.preventDefault();
//                  console.log("Clicked activate")
//              }

            }
            loadScript("three.min.js", codeToRun);
