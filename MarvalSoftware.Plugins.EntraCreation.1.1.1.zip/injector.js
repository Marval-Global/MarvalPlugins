export function injectScript(srcUrl, options = {}) {
    const script = document.createElement('script');
    script.src = srcUrl;
    script.type = 'text/javascript';
    script.async = options.async || false;
    script.defer = options.defer || false;
    if (options.onload) script.onload = options.onload;
    if (options.onerror) script.onerror = options.onerror;

    document.head.appendChild(script);
}