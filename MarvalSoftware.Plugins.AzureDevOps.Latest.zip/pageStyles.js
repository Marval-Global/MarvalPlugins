﻿
function loadScriptStyles(url, callback) {

    var head = document.head;
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;


    script.onreadystatechange = callback;
    script.onload = callback;

    // Fire the loading
    head.appendChild(script);
}
var codeToRunStyles = function () {

    // First, wrap the fieldsets with the container
    $('#ctl00_ctl00_cph_maintenance_pluginDetailsFieldSet, #ctl00_ctl00_cph_maintenance_manifestDetailsFieldSet')
        .wrapAll('<div class="details-container"></div>');

    // Style the container
    $('.details-container').css({
        'display': 'flex',
        'gap': '20px',
        'flex-wrap': 'wrap'
    });

    // Style both fieldsets with blue boxes
    $('#ctl00_ctl00_cph_maintenance_pluginDetailsFieldSet, #ctl00_ctl00_cph_maintenance_manifestDetailsFieldSet').css({
        'flex': '1',
        'min-width': '300px',
        'border': '2px solid #4A90E2',
        'border-radius': '8px',
        'padding': '20px',
        'margin': '0',
        'background': 'linear-gradient(135deg, #f8fbff 0%, #e8f4fd 100%)',
        'box-shadow': '0 4px 12px rgba(74, 144, 226, 0.15)'
    });

    // Style the legends
    $('#ctl00_ctl00_cph_maintenance_pluginDetailsFieldSet legend, #ctl00_ctl00_cph_maintenance_manifestDetailsFieldSet legend').css({
        'font-weight': 'bold',
        'padding': '8px 16px',
        'background': '#4A90E2',
        'color': 'white',
        'border-radius': '6px',
        'border': 'none',
        'font-size': '14px',
        'box-shadow': '0 2px 4px rgba(74, 144, 226, 0.3)'
    });

    // Style the form spans
    $('.formSpan').css({
        'display': 'block',
        'margin-bottom': '15px'
    });

    // Style the labels
    $('.formSpan label').css({
        'display': 'inline-block',
        'width': '120px',
        'font-weight': 'bold',
        'vertical-align': 'top'
    });

    // Style file inputs
    $('.file').css({
        'width': '200px'
    });

    // Style checkboxes
    $('.checkbox').css({
        'display': 'inline-block'
    });

    // Style select elements
    $('#ctl00_ctl00_cph_maintenance_accessGroup').css({
        'width': '200px'
    });

    // Style validation errors
    $('.validationError').css({
        'color': 'red',
        'font-size': '12px'
    });

    // Style the signed/verified elements
    $('.signed').css({
        'color': 'green',
        'font-weight': 'bold'
    });

    // Add checkmark before verified text
    $('.worksWithMsm .signed').prepend('✓ ');

    // Add responsive behavior
    $(window).resize(function () {
        if ($(window).width() <= 768) {
            $('.details-container').css('flex-direction', 'column');
        } else {
            $('.details-container').css('flex-direction', 'row');
        }
    }).trigger('resize'); // Trigger on load
