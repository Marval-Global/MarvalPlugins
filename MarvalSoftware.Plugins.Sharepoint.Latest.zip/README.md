# Sharepoint Plugin for MSM

## MSM-Sharepoint Integration

This plugin allows you to:
- Upload files and attachments in Marval to your selected Sharepoint sites and folders
- Create Sharepoint folders within Marval

## Sharepoint Integration

**Settings needed from Sharepoint:**

Within Sharepoint follow the steps outlined below:

1. Navigate to https://marvaluk.sharepoint.com/_layouts/15/sharepoint.aspx
2. Signup / Login 
3. Here you will be able to see which sites your user should have access to, if configuration is correct then you will be able to see the sharepoint sites you have access to


## Compatible Versions

| Plugin  | MSM       |Sharepoint|
|---------|-----------|----------|
| 1.0.0   | 14.15.0   | v1.0.0   |
| 1.1.5   | 15.11+    | v16.0.1  |


## Installation

Please see your MSM documentation for information on how to install plugins.

Once the plugin has been installed you will need to configure the following settings within the plugin page:

+ *Marval API Key*: The API key for the user created within MSM to perform these actions.
> To get an API key for yourself in Marval, navigate to the top left where your name appears, click on **Profile** and then click the lock icon at the top right in the icon bar which appears under the menu at the top of the page.
+ *Microsoft Application Client ID*: First go to: https://portal.azure.com/#home, then click on Microsoft Entra ID, then go the App Registrations page in the left sidebar and copy the Application (client) ID
of the desired application.
+ *Custom Attribute*: If you wish to use a custom attribute for the naming convention, make sure this matches the desired custom attribute in Marval. You can also view this through the Request Page -> Advanced. Some key examples for Sharepoint could invoice number or other unique identifiers
+ *Naming Convention*
+ *Enforce References*: If you wish to use a naming convention and uploading all your files into a subfolder, choose one of the dropdown options, if this is kept blank or none then when uploading a new subfolder will not be created
Examples:
MSM: INC-3
MSM + Custom Attribute : INC-3-"Your Custom Attribute Value"
Custom Attribute: "Your custom attribute value"

## Usage

The plugin can be launched from the quick menu after you load a new or existing request.
After every successful upload, a note will be created in which there will be a link to the upload location

## Contributing

We welcome all feedback including feature requests and bug reports. Please raise these as issues on GitHub. If you would like to contribute to the project please fork the repository and issue a pull request.
